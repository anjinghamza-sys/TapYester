# Tap Tester Android

Aplikasi contoh sederhana untuk menguji penghitung ketukan manual dan otomatis di dalam aplikasi ini sendiri.

## Build
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Compile SDK 35
- Minimum Android 6.0 (API 23)
- Java/Kotlin JVM target 17

Aplikasi ini tidak mengirim ketukan ke aplikasi lain dan bukan bot game.
