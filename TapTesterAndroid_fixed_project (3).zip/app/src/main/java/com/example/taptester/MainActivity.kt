package com.example.taptester

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var count = 0
    private var running = false
    private lateinit var counter: TextView
    private lateinit var status: TextView
    private lateinit var startButton: Button

    private val autoTap = object : Runnable {
        override fun run() {
            if (!running) return
            count++
            updateCounter()
            handler.postDelayed(this, 500L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val title = TextView(this).apply {
            text = "Tap Tester"
            textSize = 28f
            gravity = Gravity.CENTER
        }

        counter = TextView(this).apply {
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 12)
        }

        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }

        val tapButton = Button(this).apply {
            text = "Tambah 1 ketukan"
            setOnClickListener {
                count++
                updateCounter()
            }
        }

        startButton = Button(this).apply {
            text = "Mulai tes otomatis"
            setOnClickListener {
                if (running) {
                    stopTest()
                } else {
                    running = true
                    startButton.text = "Hentikan tes"
                    status.text = "Tes berjalan: 1 hitungan tiap 0,5 detik"
                    handler.post(autoTap)
                }
            }
        }

        val resetButton = Button(this).apply {
            text = "Reset hitungan"
            setOnClickListener {
                stopTest()
                count = 0
                updateCounter()
            }
        }

        layout.addView(title)
        layout.addView(counter)
        layout.addView(status)
        layout.addView(tapButton)
        layout.addView(startButton)
        layout.addView(resetButton)

        setContentView(layout)
        updateCounter()
        status.text = "Siap. Tes hanya berjalan di aplikasi ini."
    }

    private fun updateCounter() {
        counter.text = "Jumlah ketukan: $count"
    }

    private fun stopTest() {
        running = false
        handler.removeCallbacks(autoTap)
        if (::startButton.isInitialized) startButton.text = "Mulai tes otomatis"
        if (::status.isInitialized) status.text = "Tes dihentikan."
    }

    override fun onDestroy() {
        stopTest()
        super.onDestroy()
    }
}
